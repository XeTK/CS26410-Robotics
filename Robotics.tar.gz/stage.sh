echo "Running Stage!"
player simple.cfg
